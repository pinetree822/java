package _Test06;

class Point1
{
	private int x,y;
	
	public Point1(int x, int y) {
		this.x = x;
		this.y = y;
	}
	public String toString()
	{
		return "Point1(" + x + "," + y + ")";
	}
}// class Point
