package _Test07;

class Student
{
	private int id;
	private String tel;
	
	public Student(int id, String tel) { this.id=id; this.tel=tel; }
	public int getId() { return id; }
	public String getTel() { return tel; }
}
