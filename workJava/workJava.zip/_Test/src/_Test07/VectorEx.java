package _Test07;

public class VectorEx {

}
