package _Test05;

class Rect extends Shape
{
	@Override
	public void draw() { System.out.println("Rect"); }
}// class Rect
