package _Test05;

class Shape4
{
	protected String name;
	
	public void paint() { draw(); }
	public void draw() { System.out.println("Shape4"); }
}// class Shape4
