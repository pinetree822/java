package _Test05;

class Shape
{
	public Shape next;
	
	public Shape() {
		next = null;
	}
	
	public void draw() { System.out.println("Shape"); }
}// class Shape
