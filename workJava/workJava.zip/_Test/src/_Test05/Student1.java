package _Test05;

public class Student1 extends Person1
{

}
