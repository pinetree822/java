package _Test05;

//PhoneInterface ���
interface MobilePhoneInterface extends PhoneInterface {
	void sendSMS();
	void receiveSMS();
}// interface MobilePhoneInterface