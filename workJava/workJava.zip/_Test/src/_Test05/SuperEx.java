package _Test05;

public class SuperEx {
	
	public static void main(String[] args) {
		ColorPoint1 cp = new ColorPoint1(5,6,"blue");
		cp.showColorPoint(); // blue( 5, 6 )
	}
	
}// class SuperEx
