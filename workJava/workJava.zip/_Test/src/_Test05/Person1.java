package _Test05;

public class Person1 {

}
