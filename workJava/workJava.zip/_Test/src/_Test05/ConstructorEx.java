package _Test05;


public class ConstructorEx {
	
	public static void main(String[] args) {
		C c;
		c = new C();
	}
}
