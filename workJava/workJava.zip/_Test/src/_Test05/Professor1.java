package _Test05;

public class Professor1 extends Person1
{

}
