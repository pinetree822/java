package _Test05;

//Class PDA �ۼ�
class PDA {
	public int calculate(int x, int y) { return x + y; }
}// class PDA