package _Test05;

public class InheritanceEx {
	
	public static void main(String[] args) {
		Student s = new Student();
		s.set();
		s.show(); // weight :99, height :175, age :30, name :ȫ�浿
	}
	
}// class InheritanceEx
