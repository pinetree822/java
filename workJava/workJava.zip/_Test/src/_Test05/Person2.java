package _Test05;

class Person2{
	String name;
	String id;
	public Person2(String name) {
		this.name=name;
	}
}// class Person2