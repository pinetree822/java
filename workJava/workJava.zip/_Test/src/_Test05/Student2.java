package _Test05;

class Student2 extends Person2
{
	String grade;
	String department;
	public Student2(String name) {
		super(name);
	}
}// class Student2
