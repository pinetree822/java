package _Test05;

public class Researcher1  extends Person1
{

}
