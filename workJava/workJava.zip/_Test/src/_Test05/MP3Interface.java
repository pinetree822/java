package _Test05;

//MP3Interface ����
interface MP3Interface {
	public void play();
	public void stop();
}// interface MP3Interface