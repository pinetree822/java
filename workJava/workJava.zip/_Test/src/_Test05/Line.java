package _Test05;

class Line extends Shape
{
	@Override
	public void draw() { System.out.println("Line"); }
}// class Line