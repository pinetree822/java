package _nomal;

import java.awt.Frame;

public class FrameEx2 extends Frame {

	public FrameEx2() {
		super("�������׽�Ʈ");
		setSize(300,300);
		setVisible(true);
	}// FrameEx2()
	
	public static void main(String[] args) {
		
		FrameEx2 fr = new FrameEx2();
		
	}// main
	
}// class FrameEx2


