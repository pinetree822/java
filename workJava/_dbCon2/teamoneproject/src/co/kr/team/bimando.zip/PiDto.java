package co.kr.team.bimando;

import java.sql.Date;
import java.sql.*;
import java.util.*;
import java.text.*;

//DTO = Data Transfer Object => �����ͺ��̽��� �̵��ϴ� ������Ʈ(��� ����, ���ڵ�, ȸ���Ѹ�)
//set���� �����ϴ� �� setter , get ���� �����ϴ� �� getter
public class PiDto {
	// Member ���̺��� �÷��� ��� ������ ���´�.
	private String h_day;
	private String id;
	private double weight;
	private double height;
	private double food;
	private double sports;
	private double biman;
	private double height_e;
	private double weight_e;
	private double biman_e;
	private String biman_r;

	public String getH_Day() {
		return h_day;
	}

	public void setH_Day(String h_day) {

		this.h_day = h_day;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public double getWeight_e() {
		return weight_e;
	}

	public void setWeight_e(double weight_e) {
		this.weight_e = weight_e;
	}

	public double getHeight_e() {
		return height_e;
	}

	public void setHeight_e(double height_e) {
		this.height_e = height_e;
	}

	public double getFood() {
		return food;
	}

	public void setFood(Double food) {
		this.food = food;
	}

	public double getSports() {
		return sports;
	}

	public void setSports(Double sports) {
		this.sports = sports;
	}

	public double getBiman() {
		return biman;
	}

	public void setBiman(Double biman) {
		this.biman = biman;
	}
	
	public double getBiman_e() {
		return biman_e;
	}
	
	public void setBiman_e(Double biman_e) {
		this.biman_e = biman_e;
	}

	public String getBiman_r() {
		return biman_r;
	}

	public void setBiman_r(String biman_r) {

		this.biman_r = biman_r;
	}

	@Override
	public String toString() {
		return "PiDto [h_day=" + h_day + ", id=" + id + ", weight=" + weight
				+ ", height=" + height + ", food=" + food + ", sports="
				+ sports + ", biman=" + biman + ", height_e=" + height_e
				+ ", weight_e=" + weight_e + ", biman_e=" + biman_e
				+ ", biman_r=" + biman_r + "]";
	}
	
	



}// end
